<?php

interface Payment{
    public function getSales();
}

?>